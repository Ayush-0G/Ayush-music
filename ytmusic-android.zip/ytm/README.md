# YT Music Android App

A lightweight Android wrapper that runs YouTube Music (music.youtube.com) in a WebView,
with sign-in persistence, background playback via a foreground service, and back-button handling.

## Build
1. Open the folder in Android Studio (it will generate the Gradle wrapper).
2. Run on a device/emulator (minSdk 24).

## Push to GitHub
```
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

## Notes
- YouTube Music has no official public API; this simply loads the official website.
- Background playback in a WebView may conflict with YouTube's Terms of Service (it is a Premium feature). Use with a Premium account, and don't publish to Google Play without reviewing the ToS.
- Not affiliated with Google or YouTube.
